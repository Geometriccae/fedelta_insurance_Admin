---
title: Chat left quote fill
categories:
  - Communications
tags:
  - chat bubble
  - text
  - message
  - quote
---
