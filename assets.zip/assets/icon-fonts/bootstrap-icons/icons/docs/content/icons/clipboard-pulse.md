---
title: Clipboard pulse
categories:
  - Real world
tags:
  - copy
  - paste
---
